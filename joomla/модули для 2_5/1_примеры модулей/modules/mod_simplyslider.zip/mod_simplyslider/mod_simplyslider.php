<?php
/**
 * @version		$Id: images.php 1 Aug 20, 2011 9:51:20 AM Thomas $
 * @package		BTShowcase
 * @copyright	Copyright (C) 2011 Bow Themes. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

require JModuleHelper::getLayoutPath('mod_simplyslider', $params->get('layout', 'default'));


?>